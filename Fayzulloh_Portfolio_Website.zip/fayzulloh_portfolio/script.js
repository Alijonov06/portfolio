const translations = {
  uz: {
    navAbout:"Men haqimda",navSkills:"Ko‘nikmalar",navJourney:"Yo‘lim",navContact:"Aloqa",
    available:"Yangi imkoniyatlarga ochiqman",hello:"Salom, men",role:'Kelajak dasturchisi <span>&amp;</span> Computer Engineering talabasi',
    heroText:"Texnologiyalar olamiga qiziquvchi, doimiy o‘rganish va yangi g‘oyalarni amaliy loyihalarga aylantirishga intiluvchi yosh mutaxassisman.",
    contactMe:"Men bilan bog‘laning",discover:"Portfolio bilan tanishing",yearsLearning:"Yil o‘qish va tajriba",languages:"Til: Uzbek / English",curiosity:"O‘rganishga qiziqish",
    tagStudent:"Talaba",scroll:"Pastga aylantiring",aboutLabel:"01 — MEN HAQIMDA",aboutTitle:'Qiziqishdan <em>mahorat sari.</em>',
    aboutLead:"Men Fayzulloh — texnologiya, dasturlash va muammolarga ijodiy yechim topishga qiziqadigan talabaman.",
    aboutText:"Hozirda Toshkent axborot texnologiyalari universitetida kompyuter injiniringi yo‘nalishida tahsil olaman. Har bir yangi bilimni amaliyotda sinab ko‘rish, jamoa bilan ishlash va o‘z ustimda muntazam ishlashni muhim deb bilaman.",
    location:"Andijon, O‘zbekiston",value1Title:"Mantiqiy fikrlash",value1Text:"Murakkab vazifalarni kichik va tushunarli qadamlarga ajratish.",value2Title:"Doimiy rivojlanish",value2Text:"Yangi bilim va texnologiyalarni o‘rganishga tayyorman.",value3Title:"Jamoaviy ish",value3Text:"Fikr almashish va umumiy natija sari birga harakat qilish.",
    skillsLabel:"02 — KO‘NIKMALAR",skillsTitle:'Ishlash uslubim va <em>kuchli tomonlarim.</em>',skillsIntro:"Yaxshi natija bilim, intizom va hamkorlik uyg‘unligidan boshlanadi.",
    office:"Ofis dasturlari",problem:"Muammolarni hal qilish",team:"Jamoa bilan ishlash",time:"Vaqtni boshqarish",communication:"Muloqot ko‘nikmalari",learning:"Tez o‘rganish va moslashish",
    journeyLabel:"03 — TAJRIBA VA TA’LIM",journeyTitle:'Har bir qadam — <em>yangi imkoniyat.</em>',now:"Hozir",education:"TA’LIM",experience:"TAJRIBA",
    university:"Toshkent axborot texnologiyalari universiteti",universityText:"Kompyuter injiniringi yo‘nalishi · Talaba",mathTitle:"Matematika kurslari",mathText:"O‘quvchilarga matematika fanidan dars berish va mavzularni tushuntirish.",school:"12-umumiy o‘rta ta’lim maktabi",schoolText:"Marhamat tumani, Andijon viloyati",
    contactLabel:"04 — ALOQA",contactTitle:'Birgalikda ajoyib<br><em>g‘oyalar yaratamiz.</em>',contactText:"Hamkorlik, loyiha yoki shunchaki suhbat uchun men bilan bog‘laning.",made:"Maqsad bilan yaratildi.",backTop:"Yuqoriga ↑"
  },
  en: {
    navAbout:"About",navSkills:"Skills",navJourney:"Journey",navContact:"Contact",
    available:"Open to new opportunities",hello:"Hello, I'm",role:'Aspiring Developer <span>&amp;</span> Computer Engineering Student',
    heroText:"A technology enthusiast who loves continuous learning and turning fresh ideas into practical projects.",
    contactMe:"Get in touch",discover:"Explore portfolio",yearsLearning:"Years of learning",languages:"Languages: Uzbek / English",curiosity:"Curiosity to learn",
    tagStudent:"Student",scroll:"Scroll to explore",aboutLabel:"01 — ABOUT ME",aboutTitle:'From curiosity to <em>capability.</em>',
    aboutLead:"I'm Fayzulloh — a student interested in technology, programming, and finding creative solutions to problems.",
    aboutText:"I am currently studying Computer Engineering at Tashkent University of Information Technologies. I value putting new knowledge into practice, collaborating with others, and consistently improving my skills.",
    location:"Andijan, Uzbekistan",value1Title:"Logical thinking",value1Text:"Breaking complex tasks into smaller, understandable steps.",value2Title:"Continuous growth",value2Text:"Always ready to explore new knowledge and technologies.",value3Title:"Teamwork",value3Text:"Sharing ideas and working together towards a common result.",
    skillsLabel:"02 — SKILLS",skillsTitle:'How I work and <em>what I bring.</em>',skillsIntro:"Great results begin with a balance of knowledge, discipline, and collaboration.",
    office:"Office applications",problem:"Finding solutions",team:"Working with a team",time:"Managing priorities",communication:"Communication skills",learning:"Learning quickly and adapting",
    journeyLabel:"03 — EXPERIENCE & EDUCATION",journeyTitle:'Every step is a <em>new opportunity.</em>',now:"Present",education:"EDUCATION",experience:"EXPERIENCE",
    university:"Tashkent University of Information Technologies",universityText:"Computer Engineering · Student",mathTitle:"Mathematics courses",mathText:"Teaching mathematics and explaining key topics to students.",school:"Secondary School No. 12",schoolText:"Marhamat district, Andijan region",
    contactLabel:"04 — CONTACT",contactTitle:'Let’s create great<br><em>ideas together.</em>',contactText:"Reach out for collaboration, a project, or simply a conversation.",made:"Made with purpose.",backTop:"Back to top ↑"
  }
};
let language = "uz";
const langToggle = document.getElementById("langToggle");
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");
function setLanguage(lang){
  language=lang; document.documentElement.lang=lang;
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;
    if(translations[lang][key]) el.innerHTML=translations[lang][key];
  });
  langToggle.innerHTML=(lang==="uz"?"UZ":"EN")+" <span>⌄</span>";
}
langToggle.addEventListener("click",()=>setLanguage(language==="uz"?"en":"uz"));
themeToggle.addEventListener("click",()=>{
  document.body.classList.toggle("light");
  const light=document.body.classList.contains("light");
  themeIcon.textContent=light?"☾":"☼";
  document.querySelector('meta[name="theme-color"]').content=light?"#f4f5f0":"#0b0d12";
});
document.getElementById("menuToggle").addEventListener("click",()=>{
  document.getElementById("nav").classList.toggle("open");
});
document.querySelectorAll(".nav a").forEach(link=>link.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));
const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("revealed");observer.unobserve(entry.target)}});
},{threshold:.12});
document.querySelectorAll(".section-heading,.value-card,.timeline-item,.skill-item,.contact-card").forEach(el=>observer.observe(el));
const revealStyle=document.createElement("style");
revealStyle.textContent=".section-heading,.value-card,.timeline-item,.skill-item,.contact-card{opacity:0;transform:translateY(18px);transition:opacity .65s ease,transform .65s ease}.revealed{opacity:1!important;transform:translateY(0)!important}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important}}";
document.head.appendChild(revealStyle);
