FAYZULLOH — PERSONAL PORTFOLIO

Ishga tushirish:
1. ZIP faylni kompyuteringizga chiqaring (Extract All).
2. fayzulloh_portfolio papkasini oching.
3. index.html faylini brauzerda oching.

Fayllar:
- index.html  : sahifa tuzilishi
- style.css   : dizayn va responsive ko‘rinish
- script.js   : til, mavzu va menyu interaktivligi
- assets/fayzulloh.jpg : siz yuborgan portret

Sayt xususiyatlari:
- O‘zbekcha / English
- Light / Dark rejim
- Mobil va desktop ekranlarga moslashuv
- Navigatsiya va yumshoq animatsiyalar

Eslatma: Google Fonts uchun internet aloqasi kerak. Saytning asosiy funksiyalari lokal fayllar orqali ishlaydi.
